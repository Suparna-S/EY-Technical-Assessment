"""
AgentDesk · for Regulated Operations
A multi-agent decision platform UI mockup.
A single-file Streamlit app that walks through two persona experiences
(Senior Analyst and SME / Policy Owner) for the AgentDesk submission.

This is a UI mock with pre-defined values, built to support the architecture
deck and demo video, not a working agent system. See README.md for the
full framing and how the code maps to the architecture layers.
Run:  streamlit run app.py
"""

import time
from datetime import datetime

import altair as alt
import pandas as pd
import streamlit as st

# =====================================================================
# Page config
# =====================================================================
st.set_page_config(
    page_title="AgentDesk · Regulated Operations",
    layout="wide",
    initial_sidebar_state="expanded",
)

# =====================================================================
# Global CSS
# =====================================================================
st.markdown(
    """
    <style>
        #MainMenu, footer {visibility: hidden;}
        header[data-testid="stHeader"] {background-color: transparent !important;}

        /* Make the sidebar collapse/expand button always visible and prominent */
        button[data-testid="stSidebarCollapseButton"],
        button[data-testid="stSidebarCollapsedControl"],
        button[data-testid="collapsedControl"],
        [data-testid="stSidebarCollapsedControl"] {
            color: #14B8A6 !important;
            opacity: 1 !important;
            visibility: visible !important;
            z-index: 9999 !important;
        }

        /* Top user strip (right-aligned) */
        .top-strip {
            display: flex; justify-content: flex-end; align-items: center;
            gap: 14px; padding: 4px 0 16px 0;
            border-bottom: 1px solid #1E293B; margin-bottom: 22px;
            color: #94A3B8; font-size: 13px;
        }
        .prod-badge {
            background-color: #10B981; color: white;
            padding: 3px 10px; border-radius: 4px;
            font-size: 11px; font-weight: 700; letter-spacing: 0.5px;
        }

        /* Hero strip on dashboard */
        .hero {
            background: linear-gradient(135deg, #14B8A6 0%, #0F766E 100%);
            padding: 1.5rem 2rem; border-radius: 12px; margin-bottom: 1.5rem;
        }
        .hero h2 {color: white !important; margin: 0 !important; font-size: 22px !important; line-height: 1.3;}
        .hero p {color: rgba(255,255,255,0.92); margin: 10px 0 0 0; font-size: 14px; line-height: 1.55;}

        /* Generic card */
        .card {
            background-color: #1E293B; padding: 1.25rem 1.5rem;
            border-radius: 10px; border: 1px solid #334155; margin-bottom: 1rem;
        }

        /* Agent grid card */
        .agent-card {
            background-color: #1E293B; padding: 1.5rem;
            border-radius: 10px; border: 1px solid #334155;
            min-height: 220px;
        }
        .agent-card.disabled {opacity: 0.55;}
        .agent-name {font-size: 18px; font-weight: 700; color: #F1F5F9; margin-bottom: 8px;}
        .agent-desc {color: #94A3B8; font-size: 13px; line-height: 1.55; margin: 12px 0;}

        /* Status badges */
        .badge-active {
            background-color: #10B981; color: white;
            padding: 3px 10px; border-radius: 4px;
            font-size: 11px; font-weight: 700; letter-spacing: 0.5px;
        }
        .badge-coming {
            background-color: #475569; color: #CBD5E1;
            padding: 3px 10px; border-radius: 4px;
            font-size: 11px; font-weight: 700; letter-spacing: 0.5px;
        }
        .badge-amber {
            background-color: #F59E0B; color: white;
            padding: 3px 10px; border-radius: 4px;
            font-size: 11px; font-weight: 700;
        }
        .badge-green {
            background-color: #10B981; color: white;
            padding: 3px 10px; border-radius: 4px;
            font-size: 11px; font-weight: 700;
        }

        /* Domain pills on inbox */
        .pill-active {
            display: inline-block; padding: 5px 14px; border-radius: 18px;
            background-color: #14B8A6; color: white;
            font-size: 12px; font-weight: 600; margin-right: 8px;
        }
        .pill-disabled {
            display: inline-block; padding: 5px 14px; border-radius: 18px;
            background-color: transparent; color: #64748B;
            border: 1px solid #334155;
            font-size: 12px; font-weight: 500; margin-right: 8px;
        }

        /* SME skill review side-by-side panels */
        .skill-panel {
            background-color: #0F172A; border: 1px solid #334155;
            border-radius: 8px; padding: 14px 16px;
            font-size: 13px; line-height: 1.55; color: #CBD5E1;
            min-height: 320px;
        }
        .skill-panel-title {
            font-size: 11px; font-weight: 700; letter-spacing: 0.8px;
            color: #94A3B8; text-transform: uppercase;
            margin-bottom: 10px;
        }
        .skill-panel pre {
            background-color: transparent !important; padding: 0 !important;
            color: #14B8A6 !important; font-size: 12.5px !important;
            white-space: pre-wrap; line-height: 1.5;
        }

        /* Citation */
        .citation {
            background-color: #0F172A; padding: 0.6rem 0.8rem;
            border-left: 3px solid #14B8A6; margin: 0.4rem 0;
            border-radius: 4px; font-size: 13px;
        }

        /* Ledger entry block */
        .ledger-entry {
            background-color: #0F172A; border: 1px solid #334155;
            padding: 1.2rem; font-family: Consolas, Monaco, monospace;
            font-size: 13px; color: #14B8A6;
            border-radius: 6px; white-space: pre; line-height: 1.5;
        }

        /* Success / approval banner */
        .success-banner {
            background-color: #064E3B; border-left: 4px solid #10B981;
            padding: 14px 18px; border-radius: 6px;
            color: #D1FAE5; margin-bottom: 1.2rem;
            font-size: 14px;
        }

        /* Factory pipeline step */
        .factory-step {
            padding: 12px 16px; margin-bottom: 8px;
            background-color: #1E293B; border-left: 3px solid #14B8A6;
            border-radius: 4px;
        }
    </style>
    """,
    unsafe_allow_html=True,
)

# =====================================================================
# Session state
# =====================================================================
DEFAULT_STATE = {
    "page": "dashboard",
    "case_approved": False,
    "trace_done": False,
    "factory_done": False,
    "show_toast": False,
    "role": "analyst",                  # "analyst" or "sme"
    "skill_review_expanded": False,     # SME view: is the skill review section open?
    "skill_approved": False,            # SME view: has the SME approved the flagged skill?
    "sme_factory_done": False,          # SME view: has the upload pipeline animated?
}
for k, v in DEFAULT_STATE.items():
    if k not in st.session_state:
        st.session_state[k] = v


def go(page_id):
    st.session_state.page = page_id
    if page_id == "case_detail":
        st.session_state.trace_done = False
    if page_id == "agents":
        st.session_state.factory_done = False
    st.rerun()


def render_kpi(label, value, delta=None, delta_polarity="neutral", caption=None):
    """Render a KPI card as one HTML block (no empty card issue).

    Built as a single-line HTML string to avoid Streamlit's markdown parser
    interpreting indented blocks as code fences when conditional parts are empty.
    """
    delta_colors = {
        "positive": "#10B981",
        "negative": "#EF4444",
        "neutral": "#94A3B8",
    }
    delta_html = ""
    if delta:
        color = delta_colors.get(delta_polarity, "#94A3B8")
        delta_html = (
            f'<div style="color: {color}; font-size: 13px; font-weight: 600; '
            f'margin-top: 6px;">{delta}</div>'
        )
    caption_html = ""
    if caption:
        caption_html = (
            f'<div style="color: #64748B; font-size: 11px; margin-top: 12px; '
            f'line-height: 1.45;">{caption}</div>'
        )
    html = (
        '<div style="background-color: #1E293B; padding: 1.25rem 1.5rem; '
        'border-radius: 10px; border: 1px solid #334155; margin-bottom: 1rem;">'
        f'<div style="color: #94A3B8; font-size: 13px; font-weight: 500; '
        f'margin-bottom: 8px;">{label}</div>'
        f'<div style="color: #F1F5F9; font-size: 32px; font-weight: 700; '
        f'line-height: 1.1;">{value}</div>'
        f'{delta_html}'
        f'{caption_html}'
        '</div>'
    )
    st.markdown(html, unsafe_allow_html=True)


# =====================================================================
# Sidebar
# =====================================================================
with st.sidebar:
    st.markdown(
        """
        <div style="padding: 6px 0 20px 0; border-bottom: 1px solid #334155; margin-bottom: 16px;">
            <div style="font-size: 22px; font-weight: 700; color: #14B8A6; line-height: 1.1;">AgentDesk</div>
            <div style="font-size: 10px; color: #94A3B8; letter-spacing: 1.2px;
                        text-transform: uppercase; margin-top: 4px;">for Regulated Operations</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    if st.session_state.role == "analyst":
        NAV = [
            ("dashboard", "Dashboard"),
            ("inbox", "Inbox"),
            ("agents", "Agents"),
            ("audit", "Audit Log"),
            ("settings", "Settings"),
        ]
    else:  # sme
        NAV = [
            ("sme_skill_registry", "Skill Registry"),
            ("audit", "Audit Log"),
            ("settings", "Settings"),
        ]

    active_page = st.session_state.page
    if active_page == "case_detail":
        active_page = "inbox"

    for pid, label in NAV:
        if st.button(
            label,
            key=f"nav_{pid}",
            use_container_width=True,
            type="primary" if active_page == pid else "secondary",
        ):
            st.session_state.page = pid
            if pid == "agents":
                st.session_state.factory_done = False
            if pid == "sme_skill_registry":
                st.session_state.sme_factory_done = False
                st.session_state.skill_review_expanded = False
            st.rerun()

# =====================================================================
# Top user strip (every page) — with role switcher
# =====================================================================
strip_left, strip_mid, strip_right = st.columns([5, 2, 1])
with strip_left:
    st.markdown(
        '<div style="padding-top: 10px; color: #94A3B8; font-size: 13px;">'
        'Alerts (0)</div>',
        unsafe_allow_html=True,
    )
with strip_mid:
    role_display = st.selectbox(
        "Role",
        ["User · Senior Analyst", "User · SME / Policy Owner"],
        index=0 if st.session_state.role == "analyst" else 1,
        key="role_selectbox",
        label_visibility="collapsed",
    )
with strip_right:
    st.markdown(
        '<div style="padding-top: 10px; text-align: right;">'
        '<span class="prod-badge">PROD</span></div>',
        unsafe_allow_html=True,
    )
st.markdown(
    '<div style="border-bottom: 1px solid #1E293B; margin: 6px 0 22px 0;"></div>',
    unsafe_allow_html=True,
)

# Detect role change and redirect to that role's landing page
_new_role = "analyst" if role_display == "User · Senior Analyst" else "sme"
if _new_role != st.session_state.role:
    st.session_state.role = _new_role
    if _new_role == "analyst":
        st.session_state.page = "dashboard"
    else:
        st.session_state.page = "sme_skill_registry"
        st.session_state.sme_factory_done = False
        st.session_state.skill_review_expanded = False
    st.rerun()

# =====================================================================
# Brief flash toast (cleared after one render)
# =====================================================================
if st.session_state.show_toast:
    try:
        st.toast(
            "Notice sent · Audit ledger entry #874-291 created",
            icon=":material/check_circle:",
        )
    except Exception:
        st.toast("Notice sent · Audit ledger entry #874-291 created")
    st.session_state.show_toast = False


# =====================================================================
# PAGE: DASHBOARD
# =====================================================================
if st.session_state.page == "dashboard":

    st.markdown(
        """
        <div class="hero">
            <h2>AgentDesk reviews your margin operations cases automatically.</h2>
            <p>Each AI agent applies your bank's policies, drafts the formal notice, and routes
            high-value calls to you for approval — with every decision traceable back to the
            exact policy clause that justified it.</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    cases_today = 248 if st.session_state.case_approved else 247
    awaiting = 3 if st.session_state.case_approved else 4

    k1, k2, k3, k4 = st.columns(4)
    with k1:
        render_kpi(
            label="Cases processed by agents today",
            value=f"{cases_today}",
            delta="+18% vs daily avg",
            delta_polarity="positive",
            caption="AI-processed cases awaiting or completed human review today",
        )
    with k2:
        render_kpi(
            label="Awaiting your review",
            value=f"{awaiting}",
            caption="High-value cases flagged for your approval",
        )
    with k3:
        render_kpi(
            label="Avg time per case",
            value="5 min",
            delta="↓ trending down from last week",
            delta_polarity="positive",
            caption="Time from case opening to your approval",
        )
    with k4:
        render_kpi(
            label="Approved without changes",
            value="92%",
            delta="last 30 days",
            delta_polarity="neutral",
            caption="How often the agent's recommendation needed no edits",
        )

    st.markdown("&nbsp;")

    g1, g2 = st.columns(2)
    with g1:
        st.markdown("### Cases handled — last 7 days")
        st.caption("Daily volume processed by all agents across margin queues")
        days = pd.date_range(end=datetime.today(), periods=7).normalize()
        chart_data = pd.DataFrame({"day": days, "cases": [180, 195, 210, 225, 218, 232, 247]})
        chart = (
            alt.Chart(chart_data)
            .mark_line(
                point=alt.OverlayMarkDef(color="#14B8A6", size=80),
                color="#14B8A6",
                strokeWidth=3,
            )
            .encode(
                x=alt.X("day:T", title=None, axis=alt.Axis(labelColor="#94A3B8")),
                y=alt.Y("cases:Q", title="Cases", axis=alt.Axis(labelColor="#94A3B8")),
                tooltip=["day:T", "cases:Q"],
            )
            .properties(height=240)
            .configure_view(strokeOpacity=0)
            .configure_axis(grid=False)
        )
        st.altair_chart(chart, use_container_width=True)

    with g2:
        st.markdown("### Agent recommendation outcomes")
        st.caption("How analysts handled agent suggestions over the last 30 days")
        hitl_data = pd.DataFrame(
            {
                "outcome": ["Approved as-is", "Modified & approved", "Rejected"],
                "pct": [92, 6, 2],
            }
        )
        chart = (
            alt.Chart(hitl_data)
            .mark_bar()
            .encode(
                x=alt.X("pct:Q", title="% of cases", axis=alt.Axis(labelColor="#94A3B8")),
                y=alt.Y("outcome:N", title=None, sort="-x", axis=alt.Axis(labelColor="#94A3B8")),
                color=alt.Color(
                    "outcome:N",
                    scale=alt.Scale(
                        domain=["Approved as-is", "Modified & approved", "Rejected"],
                        range=["#10B981", "#F59E0B", "#EF4444"],
                    ),
                    legend=None,
                ),
                tooltip=["outcome:N", "pct:Q"],
            )
            .properties(height=240)
            .configure_view(strokeOpacity=0)
            .configure_axis(grid=False)
        )
        st.altair_chart(chart, use_container_width=True)

    st.markdown("&nbsp;")
    st.markdown("### Recent activity")

    activity_rows = []
    if st.session_state.case_approved:
        activity_rows.append(
            ("14:31", "MC-8472", "Issue $4.2M margin call · Counterparty XYZ",
             "Approved as-is", "MarginCallAgent")
        )
    activity_rows += [
        ("14:12", "MC-8470", "Issue $2.1M margin call · Acme Capital", "Approved as-is", "MarginCallAgent"),
        ("13:48", "MC-8469", "Issue $5.6M margin call · Delta Trading", "Modified & approved", "MarginCallAgent"),
        ("13:31", "MC-8468", "Issue $1.4M margin call · Beta Holdings", "Approved as-is", "MarginCallAgent"),
        ("13:14", "MC-8467", "Issue $3.3M margin call · Epsilon LLC", "Approved as-is", "MarginCallAgent"),
        ("12:52", "MC-8466", "Issue $2.7M margin call · Iota Partners", "Approved as-is", "MarginCallAgent"),
    ]
    activity_rows = activity_rows[:6]

    rows_html = ""
    for ts, case, decision, outcome, agent in activity_rows:
        rows_html += (
            f'<tr style="border-bottom: 1px solid #334155;">'
            f'<td style="padding: 10px 14px; color: #94A3B8;">{ts}</td>'
            f'<td style="padding: 10px 14px;">{case}</td>'
            f'<td style="padding: 10px 14px;">{decision}</td>'
            f'<td style="padding: 10px 14px;">{outcome}</td>'
            f'<td style="padding: 10px 14px; color: #94A3B8;">{agent}</td>'
            f'</tr>'
        )
    st.markdown(
        f"""
        <table style="width:100%; border-collapse: collapse; color: #F1F5F9;
                      background-color: #1E293B; border-radius: 8px; overflow: hidden;">
          <thead style="background-color: #334155;">
            <tr>
              <th style="padding: 10px 14px; text-align: left;">Time</th>
              <th style="padding: 10px 14px; text-align: left;">Case</th>
              <th style="padding: 10px 14px; text-align: left;">Decision</th>
              <th style="padding: 10px 14px; text-align: left;">Outcome</th>
              <th style="padding: 10px 14px; text-align: left;">Agent</th>
            </tr>
          </thead>
          <tbody>{rows_html}</tbody>
        </table>
        """,
        unsafe_allow_html=True,
    )


# =====================================================================
# PAGE: INBOX
# =====================================================================
elif st.session_state.page == "inbox":
    st.markdown("# Margin Operations Inbox")
    st.markdown(
        """
        <div style="margin-bottom: 18px;">
            <span class="pill-active">Margin operations</span>
            <span class="pill-disabled">Settlements · coming soon</span>
            <span class="pill-disabled">Trade breaks · coming soon</span>
        </div>
        """,
        unsafe_allow_html=True,
    )
    st.caption("Real-time queue of margin call cases · 4 active · triggered by exposure threshold breaches")

    if st.session_state.case_approved:
        row2_bg = "background-color: #1E293B;"
        row2_status = '<span class="badge-green">Resolved</span>'
        row2_assigned = "User · 14:31"
    else:
        row2_bg = "background-color: #1E40AF;"
        row2_status = '<span class="badge-amber">In agent review</span>'
        row2_assigned = "MarginCallAgent"

    st.markdown(
        f"""
        <table style="width:100%; border-collapse: collapse; color: #F1F5F9;
                      background-color: #1E293B; border-radius: 8px; overflow: hidden;
                      margin-top: 0.5rem;">
          <thead style="background-color: #334155;">
            <tr>
              <th style="padding: 12px; text-align: left;">Case ID</th>
              <th style="padding: 12px; text-align: left;">Counterparty</th>
              <th style="padding: 12px; text-align: right;">Exposure</th>
              <th style="padding: 12px; text-align: left;">Status</th>
              <th style="padding: 12px; text-align: left;">Assigned to</th>
            </tr>
          </thead>
          <tbody>
            <tr style="border-bottom: 1px solid #334155;">
              <td style="padding: 12px;">MC-8471</td>
              <td style="padding: 12px;">Acme Capital Partners</td>
              <td style="padding: 12px; text-align: right;">$1.8M</td>
              <td style="padding: 12px;"><span class="badge-green">Resolved</span></td>
              <td style="padding: 12px;">User · 14:12</td>
            </tr>
            <tr style="{row2_bg} border-bottom: 1px solid #334155;">
              <td style="padding: 12px; font-weight: 700;">MC-8472  ▶</td>
              <td style="padding: 12px; font-weight: 700;">Counterparty XYZ</td>
              <td style="padding: 12px; text-align: right; font-weight: 700;">$4.2M</td>
              <td style="padding: 12px;">{row2_status}</td>
              <td style="padding: 12px; font-weight: 700;">{row2_assigned}</td>
            </tr>
            <tr style="border-bottom: 1px solid #334155;">
              <td style="padding: 12px;">MC-8473</td>
              <td style="padding: 12px;">Beta Holdings Ltd</td>
              <td style="padding: 12px; text-align: right;">$2.1M</td>
              <td style="padding: 12px;"><span class="badge-amber">Awaiting review</span></td>
              <td style="padding: 12px;">Queue</td>
            </tr>
            <tr>
              <td style="padding: 12px;">MC-8474</td>
              <td style="padding: 12px;">Gamma Investments LLC</td>
              <td style="padding: 12px; text-align: right;">$5.6M</td>
              <td style="padding: 12px;"><span class="badge-amber">In agent review</span></td>
              <td style="padding: 12px;">MarginCallAgent</td>
            </tr>
          </tbody>
        </table>
        """,
        unsafe_allow_html=True,
    )

    st.markdown("&nbsp;")
    btn_label = "View case MC-8472  →" if st.session_state.case_approved else "Open case MC-8472  →"
    if st.button(btn_label, type="primary"):
        go("case_detail")


# =====================================================================
# PAGE: CASE DETAIL
# =====================================================================
elif st.session_state.page == "case_detail":

    if st.session_state.case_approved:
        st.markdown(
            """
            <div class="success-banner">
                <b>✓ Case approved.</b> Notice dispatched at 14:31:09 UTC ·
                Audit ledger entry #874-291 created · End-to-end time: 31 seconds.<br/>
                <span style="color: #A7F3D0; font-size: 13px;">
                  Lifecycle handoff:  <b>CollateralReceiptAgent</b> is now monitoring
                  counterparty response (24h SLA per CSA section 3.1).
                </span>
            </div>
            """,
            unsafe_allow_html=True,
        )

    # Case header
    status_html = (
        '<span class="badge-green">Resolved</span>'
        if st.session_state.case_approved
        else '<span class="badge-amber">Pending your approval</span>'
    )
    st.markdown(
        f"""
        <div style="display: flex; align-items: center; gap: 16px; margin-bottom: 6px;">
            <h1 style="margin: 0;">Case MC-8472</h1>
            {status_html}
        </div>
        """,
        unsafe_allow_html=True,
    )
    st.caption("Counterparty XYZ Capital Markets · detected 2026-05-10 14:28:41 UTC · Tier 2 case")

    # Counterparty + Exposure cards
    c1, c2 = st.columns(2)
    with c1:
        st.markdown(
            '<div style="background-color: #1E293B; padding: 1.25rem 1.5rem; '
            'border-radius: 10px; border: 1px solid #334155; margin-bottom: 1rem;">'
            '<div style="color: #94A3B8; font-size: 13px; font-weight: 600; '
            'text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 12px;">'
            'Counterparty</div>'
            '<div style="color: #F1F5F9; font-size: 14px; line-height: 1.75;">'
            '<b>Counterparty XYZ Capital Markets Inc.</b><br/>'
            'Credit rating:  <b>BBB</b> (S&amp;P)<br/>'
            'Legal entity ID:  549300ABCDXYZ123456<br/>'
            'Active CSA:  ISDA 2016 (executed 2018-03-12)'
            '</div></div>',
            unsafe_allow_html=True,
        )
    with c2:
        st.markdown(
            '<div style="background-color: #1E293B; padding: 1.25rem 1.5rem; '
            'border-radius: 10px; border: 1px solid #334155; margin-bottom: 1rem;">'
            '<div style="color: #94A3B8; font-size: 13px; font-weight: 600; '
            'text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 12px;">'
            'Exposure</div>'
            '<div style="color: #F1F5F9; font-size: 14px; line-height: 1.75;">'
            'Mark-to-market exposure:  <b>$4,200,000</b><br/>'
            'Existing collateral posted:  <b>$0</b><br/>'
            'CSA threshold:  <b>$3,000,000</b><br/>'
            '<b>Required margin call:  &ge; $1,200,000</b>'
            '</div></div>',
            unsafe_allow_html=True,
        )

    # Citations card (header + 3 citation blocks as one HTML string)
    st.markdown(
        '<div style="background-color: #1E293B; padding: 1.25rem 1.5rem; '
        'border-radius: 10px; border: 1px solid #334155; margin-bottom: 1rem;">'
        '<div style="color: #94A3B8; font-size: 13px; font-weight: 600; '
        'text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 12px;">'
        'Applicable policy clauses  ·  retrieved by RAG</div>'
        '<div class="citation"><b>Policy section 4.1</b> — Threshold breach: any unsecured '
        'exposure above the CSA threshold triggers a margin call within 1 business day.</div>'
        '<div class="citation"><b>Policy section 4.3</b> — Investment-grade margin rule: for '
        'BBB or above counterparties, call amount = exposure − threshold + buffer.</div>'
        '<div class="citation"><b>CSA section 3.1</b> — Counterparty XYZ specific terms: $3M '
        'threshold, $0 minimum transfer amount, 24-hour response window.</div>'
        '</div>',
        unsafe_allow_html=True,
    )

    # Agent reasoning trace (multi-agent collaboration inside MarginCallAgent)
    st.markdown("##### MarginCallAgent — sub-agent collaboration trace")
    st.caption(
        "Specialist sub-agents (Data · Policy · Calculation · Drafting · Compliance) "
        "collaborate to produce one recommendation, coordinated by the Orchestrator."
    )
    trace_steps = [
        ("0.4s", "DataAgent", "Validated inputs · enriched with risk system data · exposure $4,200,000 confirmed", "✓"),
        ("0.7s", "PolicyAgent", "Retrieved policy section 4.1, section 4.3 and CSA section 3.1 from knowledge base (RAG)", "✓"),
        ("0.9s", "PolicyAgent", "Looked up counterparty rating  →  BBB (Bloomberg, fresh)", "✓"),
        (
            "1.3s",
            "CalculationAgent",
            "Applied threshold rule:  exposure $4.2M > threshold $3.0M  AND  rating BBB  →  margin call required",
            "✓",
        ),
        ("1.6s", "CalculationAgent", "Computed call amount  →  $4,200,000 (full exposure recovery, per section 4.3)", "✓"),
        ("2.0s", "DraftingAgent", "Composed formal notice using template v3.2 (24-hour response window per CSA section 3.1)", "✓"),
        ("2.4s", "ComplianceAgent", "Policy-as-code check (OPA):  0 hard-rule violations  ·  within risk appetite", "✓"),
        ("2.5s", "Orchestrator", "Tier 2 threshold met (amount > $1M)  →  routing to senior analyst for approval", "⚠"),
    ]

    placeholder = st.empty()

    def _render_trace(steps):
        rendered = '<div class="card">'
        for ts, agent, msg, icon in steps:
            color = "#10B981" if icon == "✓" else "#F59E0B"
            rendered += (
                f'<div style="padding: 8px 0; font-family: Consolas, Monaco, monospace; '
                f'font-size: 14px;">'
                f'<span style="color: {color}; font-weight: 700; font-size: 16px;">{icon}</span>'
                f'  <span style="color: #94A3B8;">{ts}</span>'
                f'  <span style="color: #14B8A6; font-weight: 600;">[{agent}]</span>'
                f'  <span style="color: #F1F5F9;">{msg}</span></div>'
            )
        rendered += "</div>"
        placeholder.markdown(rendered, unsafe_allow_html=True)

    if not st.session_state.trace_done and not st.session_state.case_approved:
        revealed = []
        for step in trace_steps:
            revealed.append(step)
            _render_trace(revealed)
            time.sleep(0.55)
        st.session_state.trace_done = True
    else:
        _render_trace(trace_steps)

    m1, m2, m3 = st.columns(3)
    with m1:
        st.metric("Faithfulness score", "0.94", "high confidence")
    with m2:
        st.metric("Tools called", "3", "all authorized")
    with m3:
        st.metric("Reasoning time", "2.5 sec", "—")

    st.markdown("&nbsp;")

    # Recommendation panel
    if not st.session_state.case_approved:
        st.markdown(
            '<div style="background-color: #1E293B; padding: 1.25rem 1.5rem; '
            'border-radius: 10px; border: 1px solid #334155; margin-bottom: 1rem;">'
            '<div style="color: #94A3B8; font-size: 13px; font-weight: 600; '
            'text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 10px;">'
            'Recommendation  ·  Pending your approval</div>'
            '<div style="color: #F1F5F9; font-size: 22px; font-weight: 700; '
            'margin-bottom: 8px;">Issue $4,200,000 margin call to Counterparty XYZ</div>'
            '<div style="color: #CBD5E1; font-size: 14px;">'
            'Response deadline:  <b>2026-05-13 17:00 UTC</b>  (within 24h per CSA section 3.1)'
            '</div></div>',
            unsafe_allow_html=True,
        )

        rc1, rc2 = st.columns([2, 1])
        with rc1:
            st.text_area(
                "Notice draft  (editable)",
                value=(
                    "Dear Counterparty XYZ,\n\n"
                    "Pursuant to Section 3.1 of the Credit Support Annex executed on "
                    "2018-03-12, this serves as formal demand for additional collateral "
                    "in the amount of USD $4,200,000, to be transferred no later than "
                    "2026-05-13 17:00 UTC.\n\n"
                    "Failure to remit will trigger procedures defined in CSA section 3.4.\n\n"
                    "Bank Operations Desk"
                ),
                height=200,
            )
        with rc2:
            st.markdown("##### Editable fields")
            st.text_input("Call amount (USD)", value="4,200,000")
            st.text_input("Response deadline", value="2026-05-13 17:00 UTC")

        a1, a2, a3, _ = st.columns([1, 1, 1, 2])
        with a1:
            if st.button("✓  Approve as-is", type="primary", use_container_width=True):
                st.session_state.case_approved = True
                st.session_state.show_toast = True
                st.rerun()
        with a2:
            st.button("✎  Modify & approve", use_container_width=True)
        with a3:
            st.button("✗  Reject", use_container_width=True)

    else:
        st.markdown(
            """
            <div style="background-color: #1E293B; padding: 1.25rem 1.5rem;
                        border-radius: 10px; border: 1px solid #334155; margin-bottom: 1rem;">
                <div style="color: #94A3B8; font-size: 13px; font-weight: 600;
                            text-transform: uppercase; letter-spacing: 0.5px;
                            margin-bottom: 10px;">Outcome</div>
                <div style="color: #F1F5F9; font-size: 14px; line-height: 1.6;">
                    <b>Approved as-is</b> by User · Senior Analyst at 14:31:08 UTC<br/>
                    Notice dispatched via SWIFT MT 503 at 14:31:09 UTC<br/>
                    Ledger entry <b>#874-291</b> signed and written to immutable store
                </div>
                <hr style="border-color: #334155; margin: 14px 0;"/>
                <div style="color: #94A3B8; font-size: 13px; font-weight: 600;
                            text-transform: uppercase; letter-spacing: 0.5px;
                            margin-bottom: 8px;">Next agent in lifecycle</div>
                <div style="color: #F1F5F9; font-size: 14px; line-height: 1.6;">
                    <b style="color: #14B8A6;">CollateralReceiptAgent</b> is now monitoring
                    Counterparty XYZ for collateral arrival.<br/>
                    Expected by: 2026-05-13 17:00 UTC (24h SLA per CSA section 3.1)<br/>
                    If overdue or disputed, case will hand off to
                    <b style="color: #14B8A6;">EscalationAgent</b> or
                    <b style="color: #14B8A6;">DisputeResolutionAgent</b>.
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        if st.button("View audit entry  →", type="primary"):
            go("audit")


# =====================================================================
# PAGE: AGENTS
# =====================================================================
elif st.session_state.page == "agents":

    st.markdown("# Agents")
    st.caption(
        "Domain-bounded AI agents converting operational procedures into auditable decisions. "
        "Each agent reuses the same factory, governance, and observability."
    )

    st.markdown("&nbsp;")

    a1, a2, a3 = st.columns(3)

    with a1:
        st.markdown(
            """
            <div class="agent-card">
                <span class="badge-active">ACTIVE</span>
                <div class="agent-name" style="margin-top: 12px;">MarginCallAgent</div>
                <div class="agent-desc">
                    Detects exposure threshold breaches, retrieves the relevant CSA and policy
                    clauses, drafts the margin call notice, and routes high-value cases for
                    human approval.
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        if st.button("Open  →", key="open_margin", use_container_width=True, type="primary"):
            go("inbox")

    with a2:
        st.markdown(
            """
            <div class="agent-card disabled">
                <span class="badge-coming">COMING SOON</span>
                <div class="agent-name" style="margin-top: 12px;">SettlementAgent</div>
                <div class="agent-desc">
                    Investigates failed or pending trade settlements, checks counterparty
                    instructions, applies remediation policy, and proposes corrective actions
                    to the operations team.
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.button("Coming soon", key="open_settle", use_container_width=True, disabled=True)

    with a3:
        st.markdown(
            """
            <div class="agent-card disabled">
                <span class="badge-coming">COMING SOON</span>
                <div class="agent-name" style="margin-top: 12px;">TradeBreakAgent</div>
                <div class="agent-desc">
                    Reconciles trade-vs-confirmation breaks, classifies the root cause against
                    the bank's break taxonomy, and routes to the right resolution path
                    (ops, sales, or risk).
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.button("Coming soon", key="open_tb", use_container_width=True, disabled=True)

    st.markdown("---")
    st.markdown("### How AgentDesk onboards a new agent")
    st.caption(
        "Same factory pipeline for every domain — drop a procedure document, "
        "the platform converts it into a governed, evaluated, production-ready agent."
    )

    factory_steps = [
        ("Step 1", "SME drops procedure document", "Example: settlement_procedures.docx  (47 pages)"),
        ("Step 2", "Layout-aware parsing  (Azure Document Intelligence)",
         "Identifies sections, tables, clauses, and references"),
        ("Step 3", "LLM skill extraction",
         "Procedure prose is converted into structured skill JSON  (trigger, inputs, decision logic, outputs, approvals, exceptions, citations)"),
        ("Step 4", "SME diff-review",
         "Each extracted skill shown side-by-side with the source procedure for sign-off"),
        ("Step 5", "Skill registry publish",
         "Skills are versioned, signed, and stored in the registry"),
        ("Step 6", "Agent instantiated & eval suite run",
         "Agent runs against a golden test set; deployment blocked if metrics fall below threshold"),
        ("Step 7", "Shadow mode, then limited pilot, then production",
         "Same governance and observability for every agent"),
    ]

    placeholder = st.empty()

    def _render_factory(steps):
        rendered = ""
        for label, title, detail in steps:
            rendered += (
                '<div class="factory-step">'
                f'<b style="color: #14B8A6;">{label}: {title}</b>'
                f'<span style="float:right; color: #10B981; font-weight: 700;">✓</span>'
                f'<br/><span style="color: #94A3B8; font-size: 13px;">{detail}</span>'
                "</div>"
            )
        placeholder.markdown(rendered, unsafe_allow_html=True)

    if not st.session_state.factory_done:
        revealed = []
        for s in factory_steps:
            revealed.append(s)
            _render_factory(revealed)
            time.sleep(0.65)
        st.session_state.factory_done = True
    else:
        _render_factory(factory_steps)


# =====================================================================
# PAGE: SME  SKILL REGISTRY
# =====================================================================
elif st.session_state.page == "sme_skill_registry":

    st.markdown(
        """
        <div class="hero">
            <h2>Onboard new procedures · review extracted skills · publish agents to production.</h2>
            <p>You're viewing the platform as a Policy Owner / SME. Drop new procedure documents
            into the knowledge base, review the skills AI has extracted, and approve them
            before they go live to operations analysts.</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    pending_count = "1" if st.session_state.skill_approved else "2"
    published_count = "156" if st.session_state.skill_approved else "155"

    k1, k2, k3, k4 = st.columns(4)
    with k1:
        render_kpi(
            label="Procedures in knowledge base",
            value="47",
            caption="Active policy documents across all domains",
        )
    with k2:
        render_kpi(
            label="Skills published",
            value=published_count,
            caption="Live, signed skills consumable by agents",
        )
    with k3:
        render_kpi(
            label="Pending your review",
            value=pending_count,
            delta="needs SME sign-off",
            delta_polarity="negative",
            caption="Skills auto-flagged by extraction confidence",
        )
    with k4:
        render_kpi(
            label="Live agents",
            value="1",
            caption="2 more in pipeline awaiting skill review",
        )

    st.markdown("&nbsp;")

    upcol_l, upcol_r = st.columns([3, 1])
    with upcol_l:
        st.markdown("### Domain agents")
        st.caption(
            "Each agent is built from skills extracted from your procedure documents. "
            "Review and approve flagged skills below."
        )
    with upcol_r:
        if st.button(
            "⬆  Upload new procedure",
            key="sme_upload",
            use_container_width=True,
            type="primary",
        ):
            try:
                st.toast(
                    "Procedure received · extraction pipeline starting",
                    icon=":material/upload_file:",
                )
            except Exception:
                st.toast("Procedure received · extraction pipeline starting")

    st.markdown("&nbsp;")

    s1, s2, s3 = st.columns(3)

    with s1:
        st.markdown(
            """
            <div class="agent-card">
                <span class="badge-active">ACTIVE</span>
                <div class="agent-name" style="margin-top: 12px;">MarginCallAgent</div>
                <div class="agent-desc">
                    Built from <b>Internal_Margin_Policy_v3.2.pdf</b> + 4 related procedures.
                    <br/><br/>
                    <span style="color: #14B8A6;">12 skills published</span> · last updated 14 days ago
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.button(
            "View skills",
            key="view_margin_skills",
            use_container_width=True,
            disabled=True,
        )

    with s2:
        settle_badge = (
            '<span class="badge-active">READY TO PUBLISH</span>'
            if st.session_state.skill_approved
            else '<span class="badge-amber">IN REVIEW</span>'
        )
        settle_status = (
            "7 skills extracted · <span style='color: #10B981;'>all approved</span>"
            if st.session_state.skill_approved
            else "7 skills extracted · <span style='color: #F59E0B;'>2 pending your review</span>"
        )
        st.markdown(
            f"""
            <div class="agent-card">
                {settle_badge}
                <div class="agent-name" style="margin-top: 12px;">SettlementAgent</div>
                <div class="agent-desc">
                    Built from <b>settlement_procedures_v2.docx</b> + SWIFT message
                    standards reference.
                    <br/><br/>
                    {settle_status}
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        review_label = (
            "All skills approved ✓"
            if st.session_state.skill_approved
            else "Review flagged skills  →"
        )
        if st.button(
            review_label,
            key="review_settle_skills",
            use_container_width=True,
            type="primary",
            disabled=st.session_state.skill_approved,
        ):
            st.session_state.skill_review_expanded = True
            st.rerun()

    with s3:
        st.markdown(
            """
            <div class="agent-card disabled">
                <span class="badge-coming">COMING SOON</span>
                <div class="agent-name" style="margin-top: 12px;">TradeBreakAgent</div>
                <div class="agent-desc">
                    No procedures onboarded yet. Drop a trade-break taxonomy
                    document to start the extraction pipeline.
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.button(
            "Awaiting procedure upload",
            key="view_tb_skills",
            use_container_width=True,
            disabled=True,
        )

    # ----- Skill review side-by-side (expanded inline) -----
    if st.session_state.skill_review_expanded and not st.session_state.skill_approved:
        st.markdown("&nbsp;")
        st.markdown("---")
        st.markdown("### Reviewing skill · `settlement.transfer_collateral`")
        st.caption(
            "AI-extracted from settlement_procedures_v2.docx · section 5.2 · "
            "extraction confidence 0.78 · flagged for SME diff-review"
        )

        rev_l, rev_r = st.columns(2)
        with rev_l:
            st.markdown(
                """
                <div class="skill-panel">
                    <div class="skill-panel-title">Source procedure · section 5.2 (page 23)</div>
                    <div style="font-style: italic; color: #CBD5E1;">
                    "Upon receipt of a valid margin call, the settlement desk shall
                    initiate a collateral transfer to the counterparty's designated account
                    within <b>one business day (T+1)</b>. The transfer must use the
                    cash collateral type unless the counterparty's CSA specifies otherwise.
                    Transfers above <b>$10 million</b> require dual-control sign-off
                    by a settlements supervisor before release. Reference the
                    originating margin call ID in all SWIFT MT202 fields."
                    </div>
                </div>
                """,
                unsafe_allow_html=True,
            )
        with rev_r:
            st.markdown(
                """
                <div class="skill-panel">
                    <div class="skill-panel-title">Extracted skill JSON</div>
                    <pre>{
  "skill_id": "settlement.transfer_collateral",
  "version": "0.1.0",
  "trigger": "margin_call.approved",
  "inputs": {
    "margin_call_id": "string",
    "amount": "decimal",
    "currency": "string",
    "counterparty_csa": "object"
  },
  "decision_logic": {
    "sla_hours": 24,
    "default_collateral_type": "cash",
    "approval_threshold_usd": 10000000,
    "dual_control_required_above": 10000000
  },
  "outputs": {
    "swift_message": "MT202",
    "reference_margin_call_id": true
  },
  "approvals": ["settlements_supervisor"],
  "exceptions": [
    "counterparty_csa.overrides_collateral_type"
  ],
  "citations": [
    "settlement_procedures_v2.docx#section 5.2"
  ]
}</pre>
                </div>
                """,
                unsafe_allow_html=True,
            )

        st.markdown("&nbsp;")
        b1, b2, b3, _ = st.columns([1.5, 1, 1, 3])
        with b1:
            if st.button(
                "✓  Approve & publish skill",
                key="sme_approve_skill",
                use_container_width=True,
                type="primary",
            ):
                st.session_state.skill_approved = True
                st.session_state.skill_review_expanded = False
                try:
                    st.toast(
                        "Skill published to registry · agent eval suite triggered",
                        icon=":material/check_circle:",
                    )
                except Exception:
                    st.toast("Skill published · eval suite triggered")
                st.rerun()
        with b2:
            st.button("Edit JSON", key="sme_edit_skill", use_container_width=True)
        with b3:
            st.button("Reject", key="sme_reject_skill", use_container_width=True)

    # ----- Confirmation banner after approval -----
    if st.session_state.skill_approved:
        st.markdown("&nbsp;")
        st.markdown(
            """
            <div class="card" style="border-left: 4px solid #10B981;">
                <b style="color: #10B981;">✓ Skill published to registry</b>
                · `settlement.transfer_collateral` v0.1.0 · signed by SME ·
                eval suite running · SettlementAgent ready for shadow-mode deployment
                pending final compliance sign-off.
            </div>
            """,
            unsafe_allow_html=True,
        )

    # ----- Pipeline animation (educational, plays once) -----
    st.markdown("---")
    st.markdown("### How AgentDesk onboards a new agent")
    st.caption(
        "Same factory pipeline runs for every procedure document — from raw PDF to "
        "production-ready agent, with SME sign-off and automated evals at every gate."
    )

    sme_factory_steps = [
        ("Step 1", "SME drops procedure document",
         "Example: settlement_procedures_v2.docx  (47 pages)"),
        ("Step 2", "Layout-aware parsing  (Azure Document Intelligence)",
         "Identifies sections, tables, clauses, and references"),
        ("Step 3", "LLM skill extraction",
         "Procedure prose is converted into structured skill JSON  "
         "(trigger, inputs, decision logic, outputs, approvals, exceptions, citations)"),
        ("Step 4", "SME diff-review  ← you are here for low-confidence skills",
         "Each extracted skill shown side-by-side with the source procedure for sign-off"),
        ("Step 5", "Skill registry publish",
         "Skills are versioned, signed, and stored in the registry"),
        ("Step 6", "Agent instantiated & eval suite run",
         "Agent runs against a golden test set; deployment blocked if metrics fall below threshold"),
        ("Step 7", "Shadow mode, then limited pilot, then production",
         "Same governance and observability for every agent"),
    ]

    sme_placeholder = st.empty()

    def _render_sme_factory(steps):
        rendered = ""
        for label, title, detail in steps:
            rendered += (
                '<div class="factory-step">'
                f'<b style="color: #14B8A6;">{label}: {title}</b>'
                f'<span style="float:right; color: #10B981; font-weight: 700;">✓</span>'
                f'<br/><span style="color: #94A3B8; font-size: 13px;">{detail}</span>'
                "</div>"
            )
        sme_placeholder.markdown(rendered, unsafe_allow_html=True)

    if not st.session_state.sme_factory_done:
        revealed = []
        for s in sme_factory_steps:
            revealed.append(s)
            _render_sme_factory(revealed)
            time.sleep(0.55)
        st.session_state.sme_factory_done = True
    else:
        _render_sme_factory(sme_factory_steps)


# =====================================================================
# PAGE: AUDIT LOG
# =====================================================================
elif st.session_state.page == "audit":

    st.markdown("# Audit Log")
    st.caption(
        "Immutable signed decision ledger · every agent decision is recorded "
        "with the policies it cited and the analyst who approved it"
    )

    fc1, fc2, fc3, _ = st.columns([1, 1, 1, 3])
    with fc1:
        st.selectbox("Agent", ["All agents", "MarginCallAgent"], key="audit_agent")
    with fc2:
        st.selectbox("Date range", ["Today", "Last 7 days", "Last 30 days"], key="audit_date")
    with fc3:
        outcome_filter = st.selectbox(
            "Outcome",
            ["All", "Approved as-is", "Modified & approved", "Rejected"],
            key="audit_outcome",
        )

    st.markdown("&nbsp;")

    # Build the list of ledger entries
    ledger_entries = []

    if st.session_state.case_approved:
        ledger_entries.append({
            "case_id": "MC-8472",
            "time": "14:31",
            "decision": "Issue $4.2M margin call to Counterparty XYZ",
            "outcome": "Approved as-is",
            "entry_id": "#874-291",
            "ledger_text": (
                "DECISION LEDGER  ·  ENTRY #874-291\n"
                "═══════════════════════════════════════════════════════\n"
                "\n"
                "Case ID:        MC-8472\n"
                "Decision:       Issue $4,200,000 margin call to Counterparty XYZ\n"
                "Outcome:        Approved as-is\n"
                "Approved by:    User · Senior Margin Analyst\n"
                "Timestamp:      2026-05-10  14:31:08 UTC\n"
                "\n"
                "Agent:          MarginCallAgent v3.2.0\n"
                "Skill used:     margin_call.issue_notice v3.2.0\n"
                "\n"
                "Tools called:   RiskOne.getExposure(XYZ)        →  $4,200,000\n"
                "                Bloomberg.creditRating(XYZ)     →  BBB\n"
                "                SWIFTGateway.send(MT503)\n"
                "\n"
                "Sources cited:  Internal_Margin_Policy_v3.2.pdf  →  section 4.1, section 4.3\n"
                "                ISDA_CSA_2016_XYZ.pdf            →  section 3.1\n"
                "\n"
                "Action taken:   Notice dispatched (SWIFT MT 503) to XYZ at 14:31:09 UTC\n"
                "\n"
                "Signature:      Verified · HSM-signed\n"
                "Immutability:   Written to append-only ledger"
            ),
        })

    ledger_entries += [
        {
            "case_id": "MC-8470",
            "time": "14:12",
            "decision": "Issue $2.1M margin call · Acme Capital",
            "outcome": "Approved as-is",
            "entry_id": "#874-290",
            "ledger_text": (
                "DECISION LEDGER  ·  ENTRY #874-290\n"
                "═══════════════════════════════════════════════════════\n"
                "\n"
                "Case ID:        MC-8470\n"
                "Decision:       Issue $2,100,000 margin call to Acme Capital Partners\n"
                "Outcome:        Approved as-is\n"
                "Approved by:    User · Senior Margin Analyst\n"
                "Timestamp:      2026-05-10  14:12:34 UTC\n"
                "\n"
                "Agent:          MarginCallAgent v3.2.0\n"
                "\n"
                "Sources cited:  Internal_Margin_Policy_v3.2.pdf  →  section 4.1, section 4.3\n"
                "                ISDA_CSA_2016_AcmeCapital.pdf    →  section 3.1\n"
                "\n"
                "Action taken:   Notice dispatched at 14:12:35 UTC\n"
                "Signature:      Verified · HSM-signed"
            ),
        },
        {
            "case_id": "MC-8469",
            "time": "13:48",
            "decision": "Issue margin call · Delta Trading",
            "outcome": "Modified & approved",
            "entry_id": "#874-289",
            "ledger_text": (
                "DECISION LEDGER  ·  ENTRY #874-289\n"
                "═══════════════════════════════════════════════════════\n"
                "\n"
                "Case ID:        MC-8469\n"
                "Decision:       Issue margin call to Delta Trading Inc.\n"
                "Outcome:        Modified & approved\n"
                "Approved by:    User · Senior Margin Analyst\n"
                "Timestamp:      2026-05-10  13:48:22 UTC\n"
                "\n"
                "Agent:          MarginCallAgent v3.2.0\n"
                "Skill used:     margin_call.issue_notice v3.2.0\n"
                "\n"
                "Tools called:   RiskOne.getExposure(Delta)      →  $5,600,000\n"
                "                Bloomberg.creditRating(Delta)   →  A-\n"
                "                SWIFTGateway.send(MT503)\n"
                "\n"
                "Sources cited:  Internal_Margin_Policy_v3.2.pdf  →  section 4.1, section 4.3\n"
                "                ISDA_CSA_2016_DeltaTrading.pdf   →  section 3.1, section 3.4\n"
                "\n"
                "─────────────────────────────────────────────────────────────────\n"
                "ANALYST MODIFICATIONS\n"
                "─────────────────────────────────────────────────────────────────\n"
                "Field          Agent recommendation       Final value\n"
                "─────────────  ─────────────────────────  ─────────────────────────\n"
                "Call amount    $5,600,000                 $5,000,000\n"
                "Deadline       2026-05-13 17:00 UTC       2026-05-14 17:00 UTC\n"
                "\n"
                "Modified by:   User · Senior Margin Analyst   (13:48:22 UTC)\n"
                "Reason given:  Counterparty in active dispute on $600K of exposure;\n"
                "               amount reduced pending dispute resolution.\n"
                "               Deadline extended 24h per counterparty request.\n"
                "─────────────────────────────────────────────────────────────────\n"
                "\n"
                "Action taken:   Modified notice dispatched (SWIFT MT 503) at 13:48:25 UTC\n"
                "\n"
                "Signature:      Verified · HSM-signed\n"
                "Immutability:   Written to append-only ledger"
            ),
        },
        {
            "case_id": "MC-8468",
            "time": "13:31",
            "decision": "Issue $1.4M margin call · Beta Holdings",
            "outcome": "Approved as-is",
            "entry_id": "#874-288",
            "ledger_text": (
                "DECISION LEDGER  ·  ENTRY #874-288\n"
                "═══════════════════════════════════════════════════════\n"
                "\n"
                "Case ID:        MC-8468\n"
                "Decision:       Issue $1,400,000 margin call to Beta Holdings Ltd\n"
                "Outcome:        Approved as-is\n"
                "Approved by:    User · Senior Margin Analyst\n"
                "Timestamp:      2026-05-10  13:31:14 UTC\n"
                "\n"
                "Agent:          MarginCallAgent v3.2.0\n"
                "\n"
                "Sources cited:  Internal_Margin_Policy_v3.2.pdf  →  section 4.1, section 4.3\n"
                "                ISDA_CSA_2016_BetaHoldings.pdf   →  section 3.1\n"
                "\n"
                "Action taken:   Notice dispatched at 13:31:15 UTC\n"
                "Signature:      Verified · HSM-signed"
            ),
        },
        {
            "case_id": "MC-8467",
            "time": "13:14",
            "decision": "Issue $3.3M margin call · Epsilon LLC",
            "outcome": "Approved as-is",
            "entry_id": "#874-287",
            "ledger_text": (
                "DECISION LEDGER  ·  ENTRY #874-287\n"
                "═══════════════════════════════════════════════════════\n"
                "\n"
                "Case ID:        MC-8467\n"
                "Decision:       Issue $3,300,000 margin call to Epsilon LLC\n"
                "Outcome:        Approved as-is\n"
                "Approved by:    User · Senior Margin Analyst\n"
                "Timestamp:      2026-05-10  13:14:08 UTC\n"
                "\n"
                "Agent:          MarginCallAgent v3.2.0\n"
                "\n"
                "Sources cited:  Internal_Margin_Policy_v3.2.pdf  →  section 4.1, section 4.3\n"
                "                ISDA_CSA_2016_EpsilonLLC.pdf     →  section 3.1\n"
                "\n"
                "Action taken:   Notice dispatched at 13:14:09 UTC\n"
                "Signature:      Verified · HSM-signed"
            ),
        },
        {
            "case_id": "MC-8466",
            "time": "12:52",
            "decision": "Issue $2.7M margin call · Iota Partners",
            "outcome": "Approved as-is",
            "entry_id": "#874-286",
            "ledger_text": (
                "DECISION LEDGER  ·  ENTRY #874-286\n"
                "═══════════════════════════════════════════════════════\n"
                "\n"
                "Case ID:        MC-8466\n"
                "Decision:       Issue $2,700,000 margin call to Iota Partners\n"
                "Outcome:        Approved as-is\n"
                "Approved by:    User · Senior Margin Analyst\n"
                "Timestamp:      2026-05-10  12:52:41 UTC\n"
                "\n"
                "Agent:          MarginCallAgent v3.2.0\n"
                "\n"
                "Sources cited:  Internal_Margin_Policy_v3.2.pdf  →  section 4.1, section 4.3\n"
                "                ISDA_CSA_2016_IotaPartners.pdf   →  section 3.1\n"
                "\n"
                "Action taken:   Notice dispatched at 12:52:42 UTC\n"
                "Signature:      Verified · HSM-signed"
            ),
        },
    ]

    # Apply the outcome filter
    if outcome_filter != "All":
        filtered_entries = [e for e in ledger_entries if e["outcome"] == outcome_filter]
    else:
        filtered_entries = ledger_entries

    # Render
    if not filtered_entries:
        st.info(
            f"No entries match the selected outcome ('{outcome_filter}') "
            "in the current date range."
        )
    else:
        for i, entry in enumerate(filtered_entries):
            with st.expander(
                f"**{entry['case_id']}**   ·   {entry['time']}   ·   "
                f"{entry['decision']}   ·   {entry['outcome']}   ·   {entry['entry_id']}",
                expanded=(i == 0),
            ):
                st.markdown(
                    f'<div class="ledger-entry">{entry["ledger_text"]}</div>',
                    unsafe_allow_html=True,
                )


# =====================================================================
# PAGE: SETTINGS  (decorative)
# =====================================================================
elif st.session_state.page == "settings":
    st.markdown("# Settings")
    st.caption("Personal preferences and account information")

    st.markdown("&nbsp;")
    st.info(
        "Settings include personal preferences (notifications, saved filters, "
        "dashboard layout) and account / team information."
        "\n\n"
        "Configuration of agents — thresholds, routing rules, model versions, "
        "and policy logic — is governed by the bank's change management process "
        "and is not user-configurable from this screen."
    )
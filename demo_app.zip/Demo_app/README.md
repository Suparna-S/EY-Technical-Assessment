# AgentDesk — Demo UI (Streamlit)

A Streamlit app built to accompany the AgentDesk demo submission for the technical assessment. This is a UI/UX walkthrough with pre-defined values, not a working agent system. Its purpose is to give a tangible feel for the two persona experiences that the proposed architecture would enable.

## What this is and what it isn't

**What this is**
- A working Streamlit app demonstrating two persona flows: Senior Analyst and SME / Policy Owner
- Pixel-accurate UI for every screen shown in the submitted demo video
- Real working interactions: case approval, role switching, skill review, audit filtering, animated multi-step pipelines, immutable ledger view

**What this isn't**
- No live LLM calls, no real RAG retrieval, no real knowledge base, no event bus
- All values (case IDs, exposures, citations, agent traces, audit entries) are illustrative
- Built within the limited assessment window to support the deck and video, not to be production code

## Why a mock UI

Since the expected deliverable was a "short video demonstrating output", not an end-to-end implementation. A real multi-agent system would need provisioned cloud infrastructure (AI Foundry, AI Search, Cosmos DB, AKS, Service Bus), LLM access approvals and quota, document ingestion pipelines parsing real policy PDFs, integrations into the bank's risk, trading, and settlement source systems, identity and access setup, policy-as-code rules, and a curated evaluation dataset before any case could flow end to end. This app exists to convey the product idea and the user experience behind AgentDesk, the deck carries the technical depth.

## Project structure

| File | Purpose |
|---|---|
| `app.py` | Single-file Streamlit app: all pages, CSS, state management |
| `.streamlit/config.toml` | Theme, dark mode, server settings |
| `requirements.txt` | Dependencies to install: Streamlit, pandas, altair |

## How the code maps to the architecture

| Streamlit page | Architecture layer | Persona |
|---|---|---|
| Dashboard | Layer 4 (Human in the Loop) | Senior Analyst |
| Inbox + Case Detail | Layer 4 + Layer 2 (reasoning trace) | Senior Analyst |
| Agents | Layer 2 (Agent Execution) | Senior Analyst (view) |
| Audit Log | Layer 4 (Audit and Compliance Portal) | Both roles |
| Skill Registry | Layer 1 (Knowledge and Skill Foundation) | SME / Policy Owner |
| Settings | Foundation Layer (Identity and Access) | Both roles |

The role switcher in the top bar (Senior Analyst / SME) re-renders the sidebar and routes to the appropriate landing page.

## What a real implementation would replace

If this were the production codebase, the same UI shell would route to:

- An Azure AI Foundry agent for case reasoning (instead of hardcoded recommendations)
- Azure AI Search and a knowledge graph for RAG retrieval (instead of static citation strings)
- An Azure Service Bus listener for incoming events (instead of a hardcoded inbox)
- An immutable signed ledger backend (instead of hardcoded audit entries)
- A policy engine for the compliance check
- An eval suite as a deployment gate for new skills
- Hosted as a containerized web app on Azure Container Apps or AKS, CI/CD via Azure DevOps (instead of running locally as a Streamlit process)

The UI components would mostly be reused, only the data layer changes.

## Run locally

```bash
cd demo_app
pip install -r requirements.txt
streamlit run app.py